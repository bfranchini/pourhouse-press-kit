POURHOUSE - PRESS KIT
Last call is your call

A game by Bruno Franchini (solo developer, self-published)
Web: https://pourhousegame.com

CONTENTS
  key-art/      Steam capsule and 1920x1080 key art
  logos/        Transparent logo lockup + standalone icon mark
  screenshots/  Full-resolution PNG captures from the build

PERMISSIONS
You are free to record, stream and monetise video of Pourhouse,
including on YouTube, Twitch and any similar platform. These assets
may be reproduced in articles, videos and thumbnails covering the
game. Please credit the developer as "Bruno Franchini".
Link back to pourhousegame.com.

Pourhouse and the Pourhouse logo are trademarks of Bruno Franchini.
